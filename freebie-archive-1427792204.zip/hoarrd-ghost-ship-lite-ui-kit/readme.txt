FREE FONTS:
Montserrat: http://www.google.com/fonts/specimen/Montserrat
Heuristica: http://www.fontsquirrel.com/fonts/heuristica

GAUSSIAN BLUR:
There are some layers where I labeled them something such as "Gaussian Blur 50%". Whenever you see this, what you're supposed to do is that the image that you're using for that screen (e.g. music album cover art), duplicate it, turn it into a smart object, and then apply the Gaussian Blur filter (put the % that's specified). You can then edit it further if needed (e.g. enlarge it, move it around, etc.)

PHOTO CREDITS:
https://unsplash.com/
http://pixabay.com/
http://superfamous.com/
http://picjumbo.com/
http://graphicburger.com/
http://magdeleine.co/

LICENSE:
Ghost Ship Lite is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/).